
from pyspark.sql import SparkSession
from pyspark.sql.functions import sum, count, col
import os

def run_gold_demo():
    # Configuration
    NESSIE_URI = os.getenv("NESSIE_URI", "http://nessie:19120/api/v1")
    
    spark = SparkSession.builder \
        .appName("Gold-Sales-Demo") \
        .config("spark.sql.catalog.nessie.uri", NESSIE_URI) \
        .config("spark.sql.catalog.nessie.ref", "gold") \
        .getOrCreate()

    print("📈 Starting Gold Aggregation Demo...")
    
    # Read from Silver Demo
    df = spark.table("nessie.ecommerce.`orders_silver_demo@silver`")
    
    # Aggregate sales by brand
    gold_df = df.groupBy("brand") \
                .agg(sum("price").alias("total_revenue"), 
                     count("*").alias("order_count"))
    
    print("✅ Aggregated sales. Writing to nessie.ecommerce.daily_sales_demo...")
    
    gold_df.writeTo("nessie.ecommerce.daily_sales_demo").createOrReplace()
    
    print("✨ Gold Demo Complete.")
    spark.stop()

if __name__ == "__main__":
    run_gold_demo()
