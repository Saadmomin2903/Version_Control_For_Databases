
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, rand
import os

def run_platinum_demo():
    # Configuration
    NESSIE_URI = os.getenv("NESSIE_URI", "http://nessie:19120/api/v1")
    
    spark = SparkSession.builder \
        .appName("Platinum-ML-Demo") \
        .config("spark.sql.catalog.nessie.uri", NESSIE_URI) \
        .config("spark.sql.catalog.nessie.ref", "platinum") \
        .getOrCreate()

    print("💎 Starting Platinum ML Insights Demo...")
    
    # Read from Gold Demo
    df = spark.table("nessie.ecommerce.`daily_sales_demo@gold`")
    
    # Simulate ML results (Segmentation based on revenue)
    platinum_df = df.withColumn("segment", 
        when(col("total_revenue") > 100, "High Value")
        .when(col("total_revenue") > 50, "Promising")
        .otherwise("Standard")
    ).withColumn("churn_probability", rand())
    
    print("✅ Generated ML insights. Writing to nessie.ecommerce.ml_insights_demo...")
    
    platinum_df.writeTo("nessie.ecommerce.ml_insights_demo").createOrReplace()
    
    print("✨ Platinum Demo Complete.")
    spark.stop()

if __name__ == "__main__":
    run_platinum_demo()
