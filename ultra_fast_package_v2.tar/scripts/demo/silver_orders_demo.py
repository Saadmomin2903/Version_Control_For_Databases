
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date, timestamp_seconds
import os

def run_silver_demo():
    # Configuration
    NESSIE_URI = os.getenv("NESSIE_URI", "http://nessie:19120/api/v1")
    WAREHOUSE = os.getenv("WAREHOUSE", "s3a://lakehouse-prod/warehouse")
    
    spark = SparkSession.builder \
        .appName("Silver-Orders-Demo") \
        .config("spark.sql.catalog.nessie.uri", NESSIE_URI) \
        .config("spark.sql.catalog.nessie.ref", "silver") \
        .getOrCreate()

    print("🥈 Starting Silver Transformation Demo...")
    
    # Read from Bronze Demo table
    df = spark.table("nessie.ecommerce.`orders_bronze_demo@bronze`")
    
    # Simple cleaning
    df_clean = df.withColumn("order_date", to_date(col("event_time"))) \
                 .filter(col("customer_id").isNotNull()) \
                 .dropDuplicates()
    
    print(f"✅ Transformed {df_clean.count()} rows. Writing to nessie.ecommerce.orders_silver_demo...")
    
    df_clean.writeTo("nessie.ecommerce.orders_silver_demo").createOrReplace()
    
    print("✨ Silver Demo Complete.")
    spark.stop()

if __name__ == "__main__":
    run_silver_demo()
